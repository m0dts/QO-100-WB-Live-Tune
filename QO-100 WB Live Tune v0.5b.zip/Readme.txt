
A little application to allow clicking of the spectrum to automatically set Minitioune parameters!
Designed for Minitioune 0.8beta9, may not work on other versions.

UDP IP and Port must match the ones set in minitioune for remote command.
Most of the signal detect code 'borrowed' from the web monitor script :-)

LNB frequency should match your lnb, this is sent each click.
Setup your receivers in the settings tab, upto four can be added to control 4 instamces of minitioune!

Let me know of any bugs, I don't plan on spending much more time on this so please no feature requests.
Code is ugly and probably not particularly secure so use at your own risk, i'm no expert, source will be on github eventually.

I advise using the chat only if you are using this along with the BATC web monitor page to save their resource/bandwidth.

M0DTS rob@m0dts.co.uk


Revisions:
v0.5b 06/12/2019 - re-added newline at end of UDP string
v0.4b 27/10/2019 - 22KHz and DVBMode was still not  being sent correctly - fixed.
v0.3b 26/10/2019 - Multiple bug fixes, Added DVB Mode and 22KHz options for Receiver control.
v0.2b 19/10/2019 - Added Tuner Socket and LNB Volts selection
v0.1b 18/10/2019 - Added multi receiver control